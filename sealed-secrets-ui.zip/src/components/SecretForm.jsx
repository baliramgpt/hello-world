// SecretForm.jsx
import React, { useState } from "react";
import { encryptSecret } from "../utils/encrypt";

export default function SecretForm() {
  const [namespace, setNamespace] = useState("default");
  const [name, setName] = useState("");
  const [key, setKey] = useState("");
  const [value, setValue] = useState("");
  const [publicKey, setPublicKey] = useState(null);
  const [sealedSecret, setSealedSecret] = useState("");

  const handleFileUpload = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setPublicKey(e.target?.result);
      };
      reader.readAsText(file);
    }
  };

  const handleGenerate = async () => {
    if (!publicKey || !name || !key || !value) return;
    const encrypted = await encryptSecret(publicKey, value);
    const sealed = `
apiVersion: bitnami.com/v1alpha1
kind: SealedSecret
metadata:
  name: ${name}
  namespace: ${namespace}
spec:
  encryptedData:
    ${key}: ${encrypted}
  template:
    metadata:
      name: ${name}
      namespace: ${namespace}`;
    setSealedSecret(sealed);
    saveToMemory(sealed);
  };

  const saveToMemory = (yaml) => {
    const file = new File([yaml], \`\${name}-sealedsecret.yaml\`, { type: "text/yaml" });
    if (window.showSaveFilePicker) {
      (async () => {
        try {
          const handle = await window.showSaveFilePicker({
            suggestedName: \`\${name}-sealedsecret.yaml\`,
            types: [
              {
                description: "YAML file",
                accept: { "text/yaml": [".yaml"] },
              },
            ],
          });
          const writable = await handle.createWritable();
          await writable.write(file);
          await writable.close();
        } catch (err) {
          console.error("File save cancelled or failed", err);
        }
      })();
    } else {
      const blob = new Blob([yaml], { type: "text/yaml" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = \`\${name}-sealedsecret.yaml\`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  return (
    <div className="space-y-4">
      <input
        className="w-full p-2 border rounded"
        placeholder="Namespace (default)"
        value={namespace}
        onChange={(e) => setNamespace(e.target.value)}
      />
      <input
        className="w-full p-2 border rounded"
        placeholder="Secret Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <input
        className="w-full p-2 border rounded"
        placeholder="Key"
        value={key}
        onChange={(e) => setKey(e.target.value)}
      />
      <input
        className="w-full p-2 border rounded"
        placeholder="Value"
        value={value}
        onChange={(e) => setValue(e.target.value)}
      />
      <input type="file" accept=".pem" onChange={handleFileUpload} />
      <button
        onClick={handleGenerate}
        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
      >
        Generate & Save Sealed Secret
      </button>
      {sealedSecret && (
        <pre className="whitespace-pre-wrap bg-gray-100 p-4 rounded">
          {sealedSecret}
        </pre>
      )}
    </div>
  );
}
