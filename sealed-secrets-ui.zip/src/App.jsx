// App.jsx
import React from "react";
import SecretForm from "./components/SecretForm";

export default function App() {
  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-2xl mx-auto bg-white shadow-xl rounded-2xl p-6">
        <h1 className="text-2xl font-bold mb-4">Sealed Secret Generator</h1>
        <SecretForm />
      </div>
    </div>
  );
}
